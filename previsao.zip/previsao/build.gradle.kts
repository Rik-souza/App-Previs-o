plugins {
    id("com.android.application") version "8.0.2" apply false
    id("com.android.library") version "8.0.2" apply false
    id("org.jetbrains.kotlin.android") version "1.8.0" apply false // Ou sua versão preferida do Kotlin
}

buildscript {
    repositories {
        google()  // Repositório Google
        mavenCentral()  // Repositório Maven Central
    }
    dependencies {
        classpath(libs.gradle)  // Plugin Android
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.7.10")  // Kotlin Plugin
    }
}
