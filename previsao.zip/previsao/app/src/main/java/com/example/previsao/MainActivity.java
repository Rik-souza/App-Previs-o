package com.example.previsao;zzzz
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import com.example.previsao.api.WeatherService;
import com.example.previsao.model.WeatherResponse;
import com.example.previsao.network.NetworkClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configurando a Toolbar como ActionBar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Configurando o TabLayout e ViewPager
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        ViewPager viewPager = findViewById(R.id.viewPager);

        // Criando e configurando o adapter para o ViewPager
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_sobre) {
            Intent intent = new Intent(this, SobreActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
public class MainActivity extends AppCompatActivity {
    private TextView weatherInfoTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa o TextView para exibir as informações
        weatherInfoTextView = findViewById(R.id.weatherInfoTextView);

        // Chama a API para obter o clima
        getWeatherData();
    }

    private void getWeatherData() {
        // Substitua "SUA_CHAVE_DE_API" pela sua chave de API real
        String apiKey = "SUA_CHAVE_DE_API";
        String cityName = "São Paulo"; // Substitua pelo nome da cidade desejada

        // Cria o Retrofit e faz a chamada à API
        WeatherService weatherService = NetworkClient.getRetrofitInstance().create(WeatherService.class);
        weatherService.getWeather(apiKey, cityName).enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherResponse weather = response.body();
                    String weatherInfo = "Cidade: " + weather.getCityName() +
                            "\nDescrição: " + weather.getDescription() +
                            "\nTemperatura: " + weather.getTemp() + "°C";

                    // Exibe as informações na UI
                    weatherInfoTextView.setText(weatherInfo);
                } else {
                    Toast.makeText(MainActivity.this, "Falha ao obter dados da API", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Erro na requisição: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    public class MainActivity extends AppCompatActivity {

        private RecyclerView recyclerView;
        private PrevisaoAdapter adapter;
        private List<Previsao> previsoes = new ArrayList<>();

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            // Carregar previsões
            loadWeatherData();
        }

        private void loadWeatherData() {
            // Criação do serviço Retrofit
            WeatherService service = NetworkClient.getRetrofitInstance().create(WeatherService.class);

            // Chamada para a API
            Call<WeatherResponse> call = service.getWeather();
            call.enqueue(new Callback<WeatherResponse>() {
                @Override
                public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                    if (response.isSuccessful()) {
                        WeatherResponse weatherResponse = response.body();

                        // Adiciona previsões para a lista
                        if (weatherResponse != null) {
                            previsoes.add(new Previsao(weatherResponse.getDate(), weatherResponse.getTemp(), weatherResponse.getDescription()));
                            updateRecyclerView();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Erro na requisição", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<WeatherResponse> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "Falha na requisição: " + t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        private void updateRecyclerView() {
            // Atualiza o RecyclerView com os dados da API
            adapter = new PrevisaoAdapter(previsoes);
            recyclerView.setAdapter(adapter);
        }
    }
